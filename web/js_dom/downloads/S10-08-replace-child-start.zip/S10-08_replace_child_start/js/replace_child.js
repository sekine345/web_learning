// リストとボタンを配置
// ボタンをクリックしたら、リストの子要素を置換する処理
function replace() {
  // 空のli要素を作成

  // 生成したノードにid属性"newList"を付与

  // テキストノードを生成

  // 生成したノードを、空のli要素の子ノードとして追加

  // 置換前の変数oldListの参照を変数oldListに代入。
  // (参照とは、オブジェクトへのリンクのことを言う)
  // https://developer.mozilla.org/ja/docs/Glossary/Object_reference

  // 親ノードulの参照を変数parentNodeに代入

  // 既存ノードoldListを、新規に作成したli要素newListと置換
  

}
